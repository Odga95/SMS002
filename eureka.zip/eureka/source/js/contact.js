document.addEventListener("DOMContentLoaded", function () {
  document.getElementById('contactForm').addEventListener('submit', contactSubmit)
  function contactSubmit(event){
      var data = {}
      data.name = document.getElementsByName('name')[0].value
      data.email = document.getElementsByName('email')[0].value
      data.tel = document.getElementsByName('tel')[0].value
      data.msg = document.getElementsByName('msg')[0].value

      fetch(contactUrl,{
          method: 'POST',
          body: JSON.stringify(data),
          headers: {
              'Content-Type': 'application/json; charset=utf-8'
          }
      }).then(function(){
          alert('Gracias, pronto nos pondremos en contacto.');
          document.getElementById('contactForm').reset()
          gtag('event', 'enviar', { 'event_category': 'formulario', 'event_label': 'contacto', 'value': '0'});
      })
      event.preventDefault();
  }
})